var json_pompbenzin_20 = {
"type": "FeatureCollection",
"name": "pompbenzin_20",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.90162301100424, 36.487049223808533 ] } },
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.901719547808163, 36.483216900764397 ] } },
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.884934211027989, 36.487614354142082 ] } },
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.881326147981781, 36.485450828571153 ] } },
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.866375010475942, 36.476898004858946 ] } },
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.837873524712691, 36.470573741726902 ] } },
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.8329662371805, 36.472191042627664 ] } },
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.837825256310722, 36.459478147817833 ] } },
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.838425929757292, 36.452628063401754 ] } }
]
}
