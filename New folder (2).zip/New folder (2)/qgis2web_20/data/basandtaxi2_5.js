var json_basandtaxi2_5 = {
"type": "FeatureCollection",
"name": "basandtaxi2_5",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "way\/245380300", "@id": "way\/245380300", "addr_city": "قائمشهر", "addr_stree": "یاس ۶ خیابان مبارزان", "amenity": "taxi", "name": "ایستگاه سواری ساری", "bus": null, "highway": null, "public_tra": null }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 52.8611376, 36.4638484 ], [ 52.8615748, 36.4641133 ], [ 52.8616769, 36.4639914 ], [ 52.8612455, 36.4637453 ], [ 52.8611376, 36.4638484 ] ] ] ] } },
{ "type": "Feature", "properties": { "id": "way\/479576931", "@id": "way\/479576931", "addr_city": "قائم شهر", "addr_stree": "خیابان صالحی مازندرانی", "amenity": "taxi", "name": "ایستگاه سواری قائمشهر-سوادکوه", "bus": null, "highway": null, "public_tra": null }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 52.8548141, 36.4593168 ], [ 52.8552934, 36.4590963 ], [ 52.8551842, 36.4589474 ], [ 52.8547338, 36.4591806 ], [ 52.8548141, 36.4593168 ] ] ] ] } }
]
}
