var json_abvafazelab_23 = {
"type": "FeatureCollection",
"name": "abvafazelab_23",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.844494340514323, 36.444786174067296 ] } }
]
}
