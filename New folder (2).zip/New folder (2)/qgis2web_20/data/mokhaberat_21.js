var json_mokhaberat_21 = {
"type": "FeatureCollection",
"name": "mokhaberat_21",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.879443680305478, 36.473399953010798 ] } },
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.8432453956137, 36.437789441809279 ] } }
]
}
