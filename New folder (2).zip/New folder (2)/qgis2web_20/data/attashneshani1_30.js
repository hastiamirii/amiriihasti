var json_attashneshani1_30 = {
"type": "FeatureCollection",
"name": "attashneshani1_30",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "way\/245013613", "@id": "way\/245013613", "addr_city": "قائم شهر", "addr_stree": "گلستان ۶", "amenity": "fire_station", "building": "yes", "name": "ایستگاه آتش نشانی ۳" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 52.8648093, 36.4605541 ], [ 52.8650253, 36.4605464 ], [ 52.8650013, 36.4602993 ], [ 52.8648141, 36.4603109 ], [ 52.8648093, 36.4605541 ] ] ] ] } }
]
}
