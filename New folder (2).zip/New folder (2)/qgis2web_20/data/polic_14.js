var json_polic_14 = {
"type": "FeatureCollection",
"name": "polic_14",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "way\/628288794", "@id": "way\/628288794", "addr_city": "قائمشهر", "addr_stree": "یاس ۶ خیابان مبارزان", "amenity": "police", "building": "public", "name": "کلانتری ۱۱" }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 52.8622964, 36.4632556 ], [ 52.8620994, 36.4631378 ], [ 52.8618674, 36.4633721 ], [ 52.8620896, 36.463507 ], [ 52.8622964, 36.4632556 ] ] ] ] } },
{ "type": "Feature", "properties": { "id": null, "@id": null, "addr_city": null, "addr_stree": null, "amenity": null, "building": null, "name": null }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 52.88929043430452, 36.487478529202207 ], [ 52.890147198439237, 36.487430020237419 ], [ 52.889604178917239, 36.486779997178296 ], [ 52.889012890993271, 36.486964332629711 ], [ 52.88929043430452, 36.487478529202207 ] ] ] ] } },
{ "type": "Feature", "properties": { "id": null, "@id": null, "addr_city": null, "addr_stree": null, "amenity": null, "building": null, "name": null }, "geometry": { "type": "MultiPolygon", "coordinates": [ [ [ [ 52.839794204873854, 36.446785817897648 ], [ 52.840017446232906, 36.446805231662808 ], [ 52.839999345582164, 36.446523731592592 ], [ 52.839836439725573, 36.446509171216356 ], [ 52.839794204873854, 36.446785817897648 ] ] ] ] } }
]
}
