var json_attashneshani_31 = {
"type": "FeatureCollection",
"name": "attashneshani_31",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "node\/11432034670", "@id": "node\/11432034670", "addr_city": null, "addr_stree": null, "amenity": "fire_station", "building": null, "name": "آتش نشانی شماره ۵ قائم شهر" }, "geometry": { "type": "Point", "coordinates": [ 52.8629507, 36.4647072 ] } },
{ "type": "Feature", "properties": { "id": null, "@id": null, "addr_city": null, "addr_stree": null, "amenity": null, "building": null, "name": null }, "geometry": { "type": "Point", "coordinates": [ 52.887558805384337, 36.477271573880408 ] } },
{ "type": "Feature", "properties": { "id": null, "@id": null, "addr_city": null, "addr_stree": null, "amenity": null, "building": null, "name": null }, "geometry": { "type": "Point", "coordinates": [ 52.843215227862501, 36.467429612212499 ] } }
]
}
