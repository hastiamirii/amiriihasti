var json_farmandarii_26 = {
"type": "FeatureCollection",
"name": "farmandarii_26",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.874165999827895, 36.470399071210544 ] } }
]
}
