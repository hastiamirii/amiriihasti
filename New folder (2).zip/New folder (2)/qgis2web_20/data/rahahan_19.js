var json_rahahan_19 = {
"type": "FeatureCollection",
"name": "rahahan_19",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.862888121230384, 36.463006144668419 ] } }
]
}
