var json_edaremanabetabii_25 = {
"type": "FeatureCollection",
"name": "edaremanabetabii_25",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.881567489991539, 36.475389155811058 ] } },
{ "type": "Feature", "properties": { "id": null }, "geometry": { "type": "Point", "coordinates": [ 52.84321824463759, 36.436915716055211 ] } }
]
}
