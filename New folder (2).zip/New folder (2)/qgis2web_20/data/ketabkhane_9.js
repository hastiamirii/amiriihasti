var json_ketabkhane_9 = {
"type": "FeatureCollection",
"name": "ketabkhane_9",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "id": "node\/10949008446", "@id": "node\/10949008446", "amenity": "library", "internet_a": "yes", "internet_1": "customers", "name": "کتابخانه قائم", "opening_ho": "Mo-Su 09:00-21:00" }, "geometry": { "type": "Point", "coordinates": [ 52.8580617, 36.4547004 ] } }
]
}
